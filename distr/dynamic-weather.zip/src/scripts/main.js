Hooks.on('ready', function () {
   console.log('Dynamic Weather test');
});
